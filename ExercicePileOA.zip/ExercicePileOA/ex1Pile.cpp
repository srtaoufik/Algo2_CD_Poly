#include<stdio.h> 
#include "pile.h" 
 int main () {
 	unsigned i ; 
 	creePile () ; 
	assert (vide ()) ; 
	empiler( 5) ; 
	empiler ( 7) ; 
	empiler ( -5) ; 
	empiler ( 0) ; 
	empiler ( 4) ; 
 	/* retourner le dernier egale 4 */ 
 	printf ( " le dernier est %d ", dernier()) ;  
 	/* effacer le nombre 4 */ 
 	depiler (); 
 	/* dernier est 0 */ 
 	printf ( " \n le dernier est %d ", dernier ()) ;   
 	
 	
 }
