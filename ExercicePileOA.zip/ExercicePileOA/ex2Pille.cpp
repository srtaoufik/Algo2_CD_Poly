#include<stdio.h> 
#include"pile.h"  

int main () {

int n;

printf ("donner un entier \n") ; 
scanf ("%d",&n)	; 
creePile () ; 
while (n != 0 ) {
	empiler ( n%10) ; 
	n=n/10;
}
while (! vide ()) {
	printf (" %d \t", dernier () ) ; 
	depiler () ; 
	
}
	
}
