#include<stdlib.h>  
#include<assert.h> 
struct element {
	int cle ; 
	struct element*suivant ; 
}; 
 static struct element *sommet ; 
 
void creePile(void) ;
unsigned vide(void) ;
int dernier() ; 
void empiler (int ) ; 
void depiler(void) ;








