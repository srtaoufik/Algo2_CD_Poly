
/*Idée : une parenthèse fermante est associée à la dernière parenthèse ouvrante rencontrée d’où LIFO = >PILE. */
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "pile.h" /*objet abstrait */


void main( ){
	char ch[80] ; /* expression proposée */
	unsigned i, j ;

	printf("donner une expression valide \n");
    gets(ch); /* scanf("%s", ch); */

    creePile();
    for(i=0 ;i<strlen(ch) ;i++){
		if(ch[i]== '(')
			empiler(i) ;
		else if(ch[i]== ')'){
			for (j=dernier();j<=i; j++) 
				printf("%c", ch[j]);
			
			printf("\n"); /*retourner a la ligne */
			depiler() ;
		}
	} /* fin for */
} /* fin main */